! function(n) {
    var o = {};

    function c(e) {
        if (o[e]) return o[e].exports;
        var t = o[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return n[e].call(t.exports, t, t.exports, c), t.l = !0, t.exports
    }
    c.m = n, c.c = o, c.d = function(e, t, n) {
        c.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, c.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, c.t = function(t, e) {
        if (1 & e && (t = c(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
        if (c.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var o in t) c.d(n, o, function(e) {
                return t[e]
            }.bind(null, o));
        return n
    }, c.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return c.d(t, "a", t), t
    }, c.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, c.p = "", c(c.s = 3)
}({
    3: function(e, t) {
        function n() {
            "on" === localStorage.status && (document.querySelector(".country-connect").innerHTML = chrome.i18n.getMessage("connectOn"), document.getElementById("activationBtn").classList.add("active"), document.getElementById("country").classList.add("active")), "off" === localStorage.status && (document.getElementById("activationBtn").classList.remove("active"), document.getElementById("country").classList.remove("active"), document.querySelector(".country-connect").innerHTML = chrome.i18n.getMessage("connectOff")), chrome.storage.local.get(null, function(t) {
                if (t && t.country && t.locations) {
                    var e = t.locations.find(function(e) {
                        return e.country_code === t.country
                    });
                    e && (document.querySelector(".country-value").innerHTML = e.country_name, document.querySelector(".flag").style = "background-image:url('img/flags/active/".concat(e.country_code, ".svg')"))
                }
            })
        }

        function o() {
            "off" === localStorage.status ? (localStorage.setItem("status", "on"), chrome.storage.local.set({
                vpnOn: !0
            })) : "on" === localStorage.status && (localStorage.setItem("status", "off"), chrome.storage.local.set({
                vpnOn: !1
            })), n()
        }

        function c() {
            document.getElementById("country").classList.toggle("opened")
        }

        function a(e) {
            var t = e.target.innerText;
            if (t) {
                document.querySelector(".country-value").innerHTML = t, c();
                var n = e.target.dataset.code;
                document.getElementById("overlay-img").style = "background-image: url('img/overlays/".concat(n, ".jpg')"), document.querySelector(".flag").style = "background-image:url('img/flags/active/".concat(n, ".svg')"), chrome.storage.local.set({
                    country: n
                })
            }
        }
        chrome.storage.local.get("locations", function(e) {
            var t = "";
            e.locations.forEach(function(e) {
                t += '<div class="country-list-item" data-code="'.concat(e.country_code, '">\n                <div class="item-flag ').concat(e.country_code, '" data-code="').concat(e.country_code, '" style="background-image:url(\'img/flags/default/').concat(e.country_code, '.png\')"></div>\n                <div class="item-name" data-code="').concat(e.country_code, '">').concat(e.country_name, "</div>\n            </div>")
            }), document.getElementById("country-list").innerHTML = t
        }), window.onload = function() {
            for (var e = document.getElementsByClassName("country-list-item"), t = 0; t < e.length; t++) e[t].addEventListener("click", a, !1);
            document.getElementById("activationBtn").onclick = o, document.getElementsByClassName("country-select")[0].onclick = c, document.getElementsByClassName("country-arrow")[0].onclick = c, localStorage.status || (localStorage.status = "off"), n()
        }, chrome.extension.getBackgroundPage().App.updateConfig()
    }
});